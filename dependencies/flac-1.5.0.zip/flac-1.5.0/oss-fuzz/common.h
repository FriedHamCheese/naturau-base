extern int alloc_check_threshold, alloc_check_counter, alloc_check_keep_failing;
int alloc_check_threshold = INT32_MAX, alloc_check_counter = 0, alloc_check_keep_failing = 0;
